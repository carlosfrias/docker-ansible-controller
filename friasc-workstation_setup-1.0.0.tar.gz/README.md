# Ansible Collection - friasc.workstation_setup

Documentation for the collection.
